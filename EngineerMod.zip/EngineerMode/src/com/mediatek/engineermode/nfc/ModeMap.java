package com.mediatek.engineermode.nfc;

import android.widget.CheckBox;

public class ModeMap {
    CheckBox mChkBox;
    int mBit;

    ModeMap(CheckBox c, int b) {
        mChkBox = c;
        mBit = b;
    }
}